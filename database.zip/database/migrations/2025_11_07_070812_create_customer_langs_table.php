<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Exécuter la migration.
     */
    public function up(): void
    {
        Schema::create('customer_langs', function (Blueprint $table) {
            $table->integer('id_customer_lang')->primary();      // INT(11) NOT NULL PRIMARY KEY
            $table->string('name', 250);           // VARCHAR(250) NOT NULL
            $table->string('lang', 10);            // VARCHAR(10) NOT NULL
            $table->timestamps();
        });
    }

    /**
     * Annuler la migration.
     */
    public function down(): void
    {
        Schema::dropIfExists('customer_langs');
    }
};
