<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('customer_contact_profiles', function (Blueprint $table) {
            $table->integer('id_contact_profile')->primary(); // PRIMARY KEY
            $table->unsignedInteger('id_profile');
            $table->foreign('id_profile')->references('id_profile')->on('profiles')->onDelete('restrict');
            $table->unsignedInteger('id_contact');
            $table->foreign('id_customer')->references('id_customer')->on('customers')->onDelete('restrict');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('customer_contact_profiles');
    }
};
