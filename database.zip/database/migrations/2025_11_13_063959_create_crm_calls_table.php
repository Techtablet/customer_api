<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Exécuter les migrations.
     */
    public function up(): void
    {
        Schema::create('crm_calls', function (Blueprint $table) {
            $table->integer('id_crm_call')->primary(); // clé primaire
            $table->unsignedInteger('id_customer')->index(); // index sur id_customer
            
            $table->unsignedInteger('id_techtablet_seller');
            $table->foreign('id_techtablet_seller')->references('id_techtablet_seller')->on('techtablet_sellers')->onDelete('restrict');
            //status
            $table->unsignedInteger('id_crm_calls_status')->default(1);
            $table->foreign('id_crm_calls_status')->references('id_crm_calls_status')->on('crm_calls_statuses')->onDelete('restrict');

            $table->text('comment');
            $table->dateTime('date');
            $table->integer('shipping_done')->nullable()->default(0);
            $table->timestamps();
        });

        // Ajout du commentaire sur la table
        DB::statement("ALTER TABLE crm_calls COMMENT = 'Table for a new call object (CRM)'");
    }

    /**
     * Annuler les migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('crm_calls');
    }
};
